import os, sys, re, json, traceback
from typing import Any, Dict, Optional
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

bridge = None
try:
    possible_bridge_paths = [r"C:\Dev Buddy Bridge V1", os.path.join(os.path.expanduser("~"), "Dev Buddy Bridge V1")]
    for p in possible_bridge_paths:
        if os.path.isdir(p) and p not in sys.path:
            sys.path.append(p)
    from devbuddy_hooks.client import BridgeClient  # type: ignore
    bridge = BridgeClient()
except Exception as e:
    print("[Bridge] not loaded:", e)

KB_READY = True
try:
    from kb.matcher_hybrid import match_knowledge_hybrid
    from kb.conversation_state import ConversationState
    convo = ConversationState(max_turns=8)
except Exception as e:
    print("KB components not ready:", e)
    KB_READY = False
    convo = None

RAG_AVAILABLE = False
try:
    from rag import topk
    RAG_AVAILABLE = True
except Exception as e:
    pass

LLM_AVAILABLE = False
_llm = None
def _load_llm() -> Optional[Any]:
    global _llm, LLM_AVAILABLE
    if _llm is not None:
        return _llm
    try:
        from llama_cpp import Llama  # type: ignore
    except Exception as e:
        return None

    model_path = os.getenv("MISTRAL_GGUF", "").strip()
    if not model_path or not os.path.exists(model_path):
        return None

    n_ctx = int(os.getenv("LLAMA_CTX", "4096"))
    n_gpu_layers = int(os.getenv("LLAMA_N_GPU_LAYERS", "0"))
    n_threads = int(os.getenv("LLAMA_THREADS", "0")) or None
    _llm = Llama(model_path=model_path, n_ctx=n_ctx, n_gpu_layers=n_gpu_layers, n_threads=n_threads, verbose=False)
    LLM_AVAILABLE = True
    return _llm

def _mistral_interpret(user_text: str, context_text: str = "") -> Optional[str]:
    llm = _load_llm()
    if not llm:
        return None
    system = ("You are AutoForge, a friendly shop tech. "
              "Interpret the customer's wording and summarize the core automotive symptom in one short line, "
              "like 'no cabin heat after warm-up' or 'cranks but will not start'. Use prior context if given. "
              "Return ONLY the short line.")
    prompt = f"<s>[INST] {system}\nContext: {context_text}\nCustomer: {user_text}\n[/INST]"
    try:
        out = llm(prompt=prompt, max_tokens=60, temperature=0.2, stop=[\"</s>\"])
        text = out.get('choices',[{}])[0].get('text','').strip()
        return text.splitlines()[0]
    except Exception as e:
        return None

VEHICLE_RE = re.compile(r'(?P<year>19\d{2}|20\d{2})\s+(?P<make>[A-Za-z\-]+)\s+(?P<model>[A-Za-z0-9\-]+)(?:\s+(?P<trim>[A-Za-z0-9\-]+))?', re.IGNORECASE)
MAKE_NORMALIZE = {"chevy":"Chevrolet","volkswagen":"Volkswagen","vw":"Volkswagen"}

def parse_vehicle(text: str):
    m = VEHICLE_RE.search(text or "")
    if not m: return {"year": None, "make": None, "model": None, "trim": None}
    year = m.group("year"); make = m.group("make").lower(); model = m.group("model"); trim = m.group("trim") or None
    return {"year": year, "make": MAKE_NORMALIZE.get(make, make.title()), "model": model.title(), "trim": trim.upper() if trim else None}

app = FastAPI(title="AutoForge Conversational Backend", version="10.0.0-convo")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173","http://127.0.0.1:5173","https://autoforge.vercel.app"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    if bridge:
        try:
            incident_id = bridge.new_incident_id()
            bridge.report_incident({"id": incident_id, "message": str(exc), "traceback": tb, "source": "autoforge_backend", "severity": "error", "fix_attempted": False})
            try:
                print("\\n[Bridge Guidance]\\n", bridge.request_guidance(incident_id), "\\n")
            except Exception as e:
                pass
        except Exception as e:
            pass
    return JSONResponse({"error": "Internal server error"}, status_code=500)

@app.get("/health")
async def health():
    return {"status":"ok","version":"10.0.0-convo","kb":KB_READY,"rag":RAG_AVAILABLE}

@app.post("/api/ai")
async def ai_chat(request: Request, tier: str = "basic"):
    body = await request.json()
    session_id = (body.get("session_id") or "default").strip() or "default"
    user_text = (body.get("message") or body.get("query") or body.get("content") or "").strip()
    vehicle = parse_vehicle(user_text)

    context_text = ""
    if convo:
        s = convo.get(session_id)
        parts = []
        if s.get("vehicle"): parts.append(f"vehicle={s['vehicle']}")
        if s.get("symptoms"): parts.append(f"symptoms={s['symptoms'][-2:]}")
        if s.get("dtcs"): parts.append(f"dtcs={s['dtcs']}")
        if s.get("last_intent"): parts.append(f"last_intent={s['last_intent']}")
        context_text = " | ".join(parts)

    interpreted = _mistral_interpret(user_text, context_text) if _load_llm() else None
    user_for_match = f\"{user_text}\nInterpreted: {interpreted}\" if interpreted else user_text

    if not KB_READY:
        return JSONResponse({"error":"Knowledge base not loaded"}, status_code=500)

    kb_out = match_knowledge_hybrid(user_for_match, tier=tier)

    parsed = {"vehicle": vehicle, "dtcs": kb_out.get("dtc_hits", []), "intent": kb_out.get("id"), "symptom": interpreted or user_text}
    if convo: convo.record(session_id, user_text, parsed)

    friendly_intro = ""
    if "cooling.no_heat" in kb_out.get("id",""):
        friendly_intro = "Alright — if it’s still blowing cold after the engine warms up, it’s usually a coolant flow or blend door issue. "
    elif "hvac.ac_not_cold" in kb_out.get("id",""):
        friendly_intro = "Got it — A/C not cooling is often charge or airflow across the condenser. "
    elif "engine.rough_idle" in kb_out.get("id",""):
        friendly_intro = "Okay — rough idle usually points to unmetered air or weak spark at low RPM. "
    elif "electrical.no_crank" in kb_out.get("id",""):
        friendly_intro = "No crank almost always comes down to battery, connections, or the starter circuit. "

    resp = {
        "response_type": "structured",
        "vehicle": vehicle,
        "intent": kb_out.get("id"),
        "title": kb_out.get("title"),
        "systems": kb_out.get("systems"),
        "summary": (friendly_intro + (kb_out.get("summary") or "")) or "Let’s walk through a couple of quick checks.",
        "possible_causes": kb_out.get("possible_causes", []),
        "steps": kb_out.get("steps", []),
        "dtc_hits": kb_out.get("dtc_hits", []),
        "score": kb_out.get("matched_score", 0.0),
        "source": "kb+convo",
        "session_id": session_id
    }

    if resp["score"] < 0.9 and RAG_AVAILABLE:
        try:
            resp["rag_support"] = topk(user_text, k=3)
        except Exception as e:
            resp["rag_support_error"] = str(e)

    if convo: convo.push_ai(session_id, resp.get("summary",""))
    return JSONResponse(resp)
