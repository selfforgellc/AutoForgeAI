import os, re, json, pickle
from typing import Dict, Any, List, Tuple
from .loader import load_all, compile_packs

# Optional semantic imports
_SEM_MODEL = None
_SEM_AVAILABLE = False
try:
    from sentence_transformers import SentenceTransformer, util  # type: ignore
    _SEM_AVAILABLE = True
except Exception:
    _SEM_AVAILABLE = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KNOWLEDGE_DIR = os.path.join(os.path.dirname(BASE_DIR), "knowledge")
INTENT_MAP_PATH = os.path.join(BASE_DIR, "intents_map.json")
SEM_INDEX_PATH = os.path.join(BASE_DIR, "semantic_index.pkl")

# DTC pattern
DTC_RE = re.compile(r\"\\b([PUCB][0-9A-F]{4})\\b\", re.I)

SYSTEM_KEYWORDS = {
    "cooling": ["heater","heat","warm air","no heat","overheat","temp gauge","heater core","blend door"],
    "hvac": ["ac","a/c","air conditioning","not cold","warm air from vents","compressor","condenser"],
    "engine": ["misfire","rough idle","hesitation","stall","p030","p0171","p0174","maf","throttle"],
    "electrical": ["no crank","battery","alternator","parasitic draw","ground","voltage"],
    "transmission": ["slip","rpm flare","hard shift","gear ratio","tcc"],
    "brakes": ["soft pedal","spongy","abs","brake light"],
    "suspension": ["vibration","shake","alignment","tie rod","ball joint"]
}

def extract_dtcs(text: str) -> List[str]:
    return [m.group(1).upper() for m in DTC_RE.finditer(text or "")]

def _load_intent_map() -> Dict[str, str]:
    try:
        with open(INTENT_MAP_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _load_semantic_index():
    if not _SEM_AVAILABLE:
        return None
    if os.path.exists(SEM_INDEX_PATH):
        try:
            with open(SEM_INDEX_PATH, "rb") as f:
                return pickle.load(f)  # { 'model_name': str, 'vectors': np.ndarray, 'ids': [id], 'texts': [str] }
        except Exception:
            return None
    return None

def _load_sem_model(model_name: str = "all-MiniLM-L6-v2"):
    global _SEM_MODEL
    if not _SEM_AVAILABLE:
        return None
    if _SEM_MODEL is None:
        _SEM_MODEL = SentenceTransformer(model_name)
    return _SEM_MODEL

def _semantic_candidates(user_text: str, k: int = 5) -> List[Tuple[str, float]]:
    idx = _load_semantic_index()
    if not idx:
        return []
    model = _load_sem_model(idx.get("model_name","all-MiniLM-L6-v2"))
    try:
        import numpy as np  # type: ignore
    except Exception:
        return []
    u = model.encode([user_text], normalize_embeddings=True)
    sims = (u @ idx["vectors"].T).flatten()
    top = sims.argsort()[-k:][::-1]
    out = []
    for i in top:
        out.append((idx["ids"][i], float(sims[i])))
    return out

def _system_bias(text_lc: str, systems: List[str]) -> float:
    bias = 0.0
    for sys in systems:
        for kw in SYSTEM_KEYWORDS.get(sys, []):
            if kw in text_lc:
                bias += 0.2
    return bias

def _smart_literal_hit(pat: str, text_lc: str) -> float:
    text_clean = re.sub(r'[^a-z0-9\\s]', ' ', text_lc)
    words = set(text_clean.split())
    phrase_words = set(re.sub(r'[^a-z0-9\\s]', ' ', pat.lower()).split())
    if phrase_words and phrase_words.issubset(words):
        return 1.0
    if any(w in words for w in phrase_words):
        return 0.5
    return 0.0

def score_item(item: Dict[str, Any], text_lc: str, dtcs: List[str], dtc_index: Dict[str, Any]) -> float:
    score = 0.0
    for kind, pat in item.get("_inc", []):
        if kind == "lit":
            score += _smart_literal_hit(pat, text_lc)
        elif kind == "re" and pat.search(text_lc):
            score += 1.5
    for kind, pat in item.get("_exc", []):
        hit = False
        if kind == "lit":
            hit = _smart_literal_hit(pat, text_lc) >= 0.5
        elif kind == "re" and pat.search(text_lc):
            hit = True
        if hit:
            score -= 3.0
    wanted = set([c.upper() for c in item.get("dtc_bonus", [])])
    if wanted:
        matched = len(wanted.intersection(dtcs))
        score += matched * 0.75
    score += _system_bias(text_lc, item.get("systems", []))
    return score

def match_knowledge_hybrid(message: str, tier: str = "basic") -> Dict[str, Any]:
    packs = load_all()
    compiled = compile_packs(packs)
    dtc_index = packs.get("dtc_index", {})
    text_lc = (message or "").lower()
    dtcs = extract_dtcs(message or "")
    intent_map = _load_intent_map()

    best_rule: Tuple[float, Dict[str, Any]] = (-999.0, None)
    for item in compiled:
        s = score_item(item, text_lc, dtcs, dtc_index)
        if s > best_rule[0]:
            best_rule = (s, item)

    boost_ids = set()
    for phrase, tag in intent_map.items():
        if phrase in text_lc:
            for item in compiled:
                if tag == "no_heat" and "cooling" in item.get("systems", []):
                    boost_ids.add(item.get("id"))
                if tag == "ac_not_cold" and "hvac" in item.get("systems", []):
                    boost_ids.add(item.get("id"))
                if tag == "misfire" and "engine" in item.get("systems", []):
                    boost_ids.add(item.get("id"))
                if tag == "rough_idle" and "engine" in item.get("systems", []):
                    boost_ids.add(item.get("id"))
                if tag == "cranks_no_start" and "engine" in item.get("systems", []):
                    boost_ids.add(item.get("id"))

    sem_hits = _semantic_candidates(message, k=5) if _SEM_AVAILABLE else []
    sem_boost = {kb_id: sc for kb_id, sc in sem_hits}

    final_best = (-999.0, None)
    for item in compiled:
        s = score_item(item, text_lc, dtcs, dtc_index)
        if item.get("id") in boost_ids:
            s += 0.6
        s += sem_boost.get(item.get("id"), 0.0) * 1.2
        if s > final_best[0]:
            final_best = (s, item)

    score, item = final_best
    if not item or score < 0.75:
        return {
            "id":"generic.insufficient_data",
            "title":"Need more details",
            "systems":[],
            "summary":"I couldn’t confidently pin that down. Tell me when it happens (cold start, warmed up, at idle, at speed) and any warning lights or codes.",
            "possible_causes":[{"name":"Insufficient data","description":"Not enough detail to identify the system confidently.","likelihood":""}],
            "steps":[{"step":"Add details","details":"Share conditions (hot/cold, at idle, on highway), noises/smells, and any DTC codes.","tools":"None","expected":""}],
            "matched_score": round(score, 2)
        }

    tiers = item.get("tiers", {})
    tier_cfg = tiers.get(tier, {})
    steps = item.get("steps", [])
    max_steps = tier_cfg.get("max_steps", len(steps))
    out_steps = steps[:max_steps]
    if tier_cfg.get("language_level") == "simple":
        import re as _re
        repl = {r"\\bverify\\b": "check", r"\\bperform\\b":"do", r"\\bdiagnostic\\b":"test"}
        _tmp = []
        for s in out_steps:
            d = s.get("details","")
            for k,v in repl.items():
                d = _re.sub(k, v, d, flags=_re.IGNORECASE)
            _tmp.append({**s, "details": d})
        out_steps = _tmp

    return {
        "id": item.get("id"),
        "title": item.get("title"),
        "systems": item.get("systems", []),
        "summary": item.get("summary", ""),
        "possible_causes": item.get("causes", []),
        "steps": out_steps,
        "dtc_hits": [d for d in dtcs if d in item.get("dtc_bonus", [])],
        "matched_score": round(score, 2)
    }
